#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Local game saves for StarCraft: Remastered EUD maps."""
import random

from eudplib import *

import scbank_core as c


def Save():
    """Issue save game data for CurrentPlayer"""
    c._issue_saveload(c._ISSUE_SAVE)


def Load():
    """Issue load game data for CurrentPlayer"""
    c._issue_saveload(c._ISSUE_LOAD)


def KST():
    c._issue_saveload(c._ISSUE_KST)


def Add(v, max_value=0xFFFFFFFF):
    """Add variable to be stored in savefile"""
    if type(v) not in (EUDArray, EUDVArray(8)):
        if v not in (Ore, Gas):
            v = EncodeUnit(v)
            ep_assert(isinstance(v, int), "Invalid type for SCBank: %s" % type(v))
    c._savedata.append((v, max_value & 0xFFFFFFFF))
