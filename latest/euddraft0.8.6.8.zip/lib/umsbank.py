from eudplib import *

_issue_save = EUDArray(8)


@EUDFunc
def Save():
    cp = f_getcurpl()
    Save


@EUDFunc
def Load():
    cp = f_getcurpl()
